4 different experiments each testing a different element of serial dependence in radiology:
 - [x] Tumor Classification
 - [ ] Tumor Detection
 - [ ] Tumor Localization
 - [ ] Tumor Search Times
